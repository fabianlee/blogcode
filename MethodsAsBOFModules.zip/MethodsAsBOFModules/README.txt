MethodsAsBOFModules
----------------------------

This project was developed by the EMC OnDemand team in order to jumpstart a developer's use of 
hot deployed BOF modules using IDfmethod (versus the legacy IDmMethod interface).

The full explanation for the advantages of the newer model are explained in this blog post:
https://community.emc.com/people/FabianLee-EMC/blog/2013/02/24/emc-ondemand-best-practices-for-custom-methods


PROJECT LAYOUT
----------------------------

src/
	com/emc/ondemand/sample/methods/
		TestModule.java - custom method that establishes a session to the 
			repository, outputs dm_server_config.object_name to log 
		TestWorkflowModule.java - custom method invoked from a workflow, outputs 
			dm_server_config.object_name to log and completes workitem 
					
Artifacts/
	JAR Definitions - packages each jar into its own jar definition
	Methods - defined methods
	Modules - defined modules



DEPLOYMENT INSTRUCTIONS
----------------------------

1. Unzip the MethodsAsBOFObjects.zip into a local directory (e.g. c:\temp\MethodsAsBOFObjects)
2. Open Composer
3. Import Composer project
	File > Import > Documentum > Existing Projects into Workspace
		Enter the full path of the unzipped directory (e.g. c:\temp\MethodsAsBOFObjects)
		Press "Browse"
		Then "Finish"
4. Right-click the project name in the explorer view, and select 'Install Documentum project'



----------------------------
VALDATION TESTS
----------------------------

To see the method in action, execute the Method from either DA or the Content Server
dql> EXECUTE do_method WITH method = 'TestModuleMethod', arguments ='-user_name <installowner> -docbase_name <docbase> -myparam thisisatest'
s
Then look at the following logs:
	a) docbase log on the Content Server to view the method trace (<repository>.log)
	b) JMS ServerApps.log for WARN level from DfLogger, and JMS server.log for stdout
	

Similar results can be seen by setting an autoactivity action to 'TestWorkflowModuleMethod'.  If Proces



Additional References:
http://paulcwarren.wordpress.com/2009/01/20/jar-defs-and-java-libraries/
http://paulcwarren.wordpress.com/2008/10/20/methods-as-bof-modules/
https://community.emc.com/docs/DOC-4360