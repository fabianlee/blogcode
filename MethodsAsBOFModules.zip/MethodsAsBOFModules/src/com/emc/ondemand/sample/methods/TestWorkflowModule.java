/**
 * Example of using hot-deployable IDfMethod for workflow method (versus legacy IDmMethod)
 * 
 * @author Fabian Lee
 * 
 * Invocation must happen via workflow (select action 'TestWorkflowModuleMethod' in autoactivity)
 * 
 * Output to: 
 * 		JMS ServerApps.log
 * 		JMS server.log
 * 		method launch trace goes to docbase log

 */
package com.emc.ondemand.sample.methods;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import com.documentum.fc.methodserver.IDfMethod;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;


public class TestWorkflowModule extends DfSingleDocbaseModule implements IDfMethod
{
	
    private PrintWriter pw;
	  
	  
	@Override
	public int execute(Map parameters, PrintWriter writer) throws Exception {
		this.pw = writer;
		MethodHelper.debug("TestWorkflowModule.execute()");

		
		// get parameters from workflow invoker
		HashMap params = MethodHelper.initParams(parameters);

		// get session
		IDfSessionManager sessionMgr = MethodHelper.login(
				(String)params.get(MethodHelper.WF_DOCBASE_KEY),
				(String)params.get(MethodHelper.WF_USER_KEY),
				(String)params.get(MethodHelper.WF_TICKET_KEY)
				);
		if (sessionMgr == null) {
			MethodHelper.debug("sorry! dctm session mgr not created, ending method call");
			return 1;
		}

		IDfSession session = null;
	        
        try {
            session = sessionMgr.getSession((String)params.get(MethodHelper.WF_DOCBASE_KEY));
			if (session == null) {
				MethodHelper.debug("sorry! dctm session not established, ending method call");
				return 1;
			}
            
            // now show which server config is being used
            MethodHelper.debug("session to repository using serverconfig=" + session.getServerConfig().getString("object_name"));

            // processing workflow workitem 
            String workitemIdStr = params.containsKey(MethodHelper.WF_WORKITEM_KEY_2) ? 
            		(String) params.get(MethodHelper.WF_WORKITEM_KEY_2):(String) params.get(MethodHelper.WF_WORKITEM_KEY);
            if(workitemIdStr==null || workitemIdStr.length()<1) {
            	MethodHelper.debug("did not find the workitem, aborting.");
            }else {
            	// process and complete workitem
	            IDfId workitemID = new DfId(workitemIdStr);
	            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
	            MethodHelper.debug("workitem.activity name=" + workitem.getActivity().getObjectName());
	        	processWorkitem(session,workitem);
            }
            
        } catch (Exception e) {
        	MethodHelper.error("Unexpected error : " + e.getMessage(),e);
            return 1;
        } finally {
            if ( session != null )
                sessionMgr.release(session);
        }
	        
		MethodHelper.debug("TestWorkflowModule.execute() returning");
		return 0;
	}
	
    public void processWorkitem(IDfSession session,IDfWorkitem workitem) throws Exception {

		MethodHelper.debug("runtimestate=" + workitem.getRuntimeState() + " performer=" + workitem.getPerformerName());
        if(workitem.getRuntimeState()==0) {
        	
        	MethodHelper.debug("going to acquire workitem");
        	workitem.acquire();
    	
        	// show all packages
			IDfCollection packageCollection = null;
			try {
				packageCollection = workitem.getPackages(null);
	
		        // get packages
		        if (packageCollection.getState() == IDfCollection.DF_READY_STATE) {
		            while (packageCollection.next()) {
		            	
		            	MethodHelper.debug("Examining package : " + packageCollection.getString("r_package_name"));
		            	MethodHelper.debug("\tcomponent_id=" + packageCollection.getString("r_component_id"));
		                
		                // show details of activity
		            	showActivityInfo(workitem);
	
		            }
		        }
			}finally {
				if(packageCollection!=null) packageCollection.close();
			}
	 
	        workitem.complete();
        }else {
        	
        	MethodHelper.debug("workitem not initially in acquire mode, not sure what to do, but going to try to complete");
        	try {
        		workitem.complete();
        	}catch(Exception exc) {
        		MethodHelper.error("could not complete workitem not initially in acquired state", exc);
        	}
        	
        }
    }
    
   public void showActivityInfo(IDfWorkitem workitem) throws DfException {
	   MethodHelper.debug("Current state=" + workitem.getActivity().getObjectName());
   	
       // show possible routes
		IDfList nextListNames = workitem.getNextActivityNames();                
		IDfList forwardList = workitem.getForwardActivities();
		IDfList rejectList = workitem.getRejectActivities();
		IDfList backListNames = workitem.getPreviousActivityNames();
		MethodHelper.debug("Past Names:");
		for(int i=0;i<backListNames.getCount();i++) {
			MethodHelper.debug("\t" + ((String) backListNames.get(i)));
		}
		MethodHelper.debug("Next Names:");
		for(int i=0;i<nextListNames.getCount();i++) {
			MethodHelper.debug("\t" + ((String) nextListNames.get(i)));
		}
		MethodHelper.debug("Forwards:");
		for(int i=0;i<forwardList.getCount();i++) {
			MethodHelper.debug("\t" + ((IDfActivity) forwardList.get(i)).getObjectName());
		}
		MethodHelper.debug("Rejects:");
		for(int i=0;i<rejectList.getCount();i++) {
			MethodHelper.debug("\t" + ((IDfActivity) rejectList.get(i)).getObjectName());
		}
		MethodHelper.debug("PORTS:");
		for(int i=0;i<workitem.getOutputPortCount();i++) {
			MethodHelper.debug("\t" + workitem.getOutputPort(i));
		}
   }
    
	

} // class
