/**
 * Example of using hot-deployable IDfMethod method  (versus legacy IDmMethod)
 * 
 * @author Fabian Lee
 * 
 * Example invocation:
 * dql> EXECUTE do_method WITH method = 'TestModuleMethod', arguments ='-user_name <installowner> -docbase_name <docbase> -myparam thisisatest'
 * 
 * Output to: 
 * 		JMS ServerApps.log
 * 		JMS server.log
 * 		method launch trace goes to docbase log
 */
package com.emc.ondemand.sample.methods;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import com.documentum.fc.methodserver.IDfMethod;
import com.documentum.fc.client.*;

public class TestModule extends DfSingleDocbaseModule implements IDfMethod {

	private PrintWriter pw;

	@Override
	public int execute(Map args, PrintWriter writer) throws Exception {
		this.pw = writer;
		MethodHelper.debug("TestModule.execute(), pw=" + pw);

		HashMap params = MethodHelper.initParams(args);

		// get session
		IDfSessionManager sessionMgr = MethodHelper.login(
				(String)params.get(MethodHelper.DOCBASE_KEY),
				(String)params.get(MethodHelper.USER_KEY),
				(String)params.get(MethodHelper.PASSWORD_KEY)
				);
		if (sessionMgr == null) {
			MethodHelper.debug("sorry! dctm session mgr not created, ending method call");
			return 1;
		}
		IDfSession session = null;

		try {
			session = sessionMgr.getSession((String)params.get(MethodHelper.DOCBASE_KEY));
			if (session == null) {
				MethodHelper.debug("sorry! dctm session not established, ending method call");
				return 1;
			}

			// now show which server config is being used
			MethodHelper.debug("session to repository using serverconfig="
					+ session.getServerConfig().getString("object_name"));
			
	
		} catch (Exception e) {
			MethodHelper.error("Unexpected error : " + e.getMessage(), e);
			throw e;
		} finally {
			if (session != null)
				sessionMgr.release(session);
		}

		MethodHelper.debug("TestModule.Execute() returning");

		return 0;
	}
	

} // class
