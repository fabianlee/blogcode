/**
 * supporting methods for parsing method parameters, establishing session, etc.
 * for both regular methods and autoactivities invoked from workflows
 * 
 * @author Fabian Lee
 * 
*/ 
package com.emc.ondemand.sample.methods;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

public class MethodHelper {

	// parameter keys for regular method invoker
	public static final String USER_KEY = "user_name";
	public static final String DOCBASE_KEY = "docbase_name";
	public  static final String PASSWORD_KEY = "password";
	public  static final String DOMAIN_KEY = "domain";
	public  static final String JOBID = "job_id";
	public  static final String MTL = "method_trace_level";
	
    // parameter keys from workflow method invoker 
    public static final String WF_USER_KEY = "user";
    public  static final String WF_DOCBASE_KEY = "docbase_name";
    public  static final String WF_WORKITEM_KEY = "packageId";
    public  static final String WF_WORKITEM_KEY_2 = "workitemId";
    public  static final String WF_TICKET_KEY = "ticket";
    public  static final String WF_MODE_KEY = "mode";
	
	
	
	public static void debug(String s) {
		DfLogger.debug(MethodHelper.class, "DEBUG-" + s, null, null);
		DfLogger.warn(MethodHelper.class, "WARN-" + s, null, null);
		System.out.println("OUT-" + s);
	}

	public static void error(String s, Throwable t) {
		DfLogger.error(MethodHelper.class, s, null, t);
		String msg = s + ";" + t.getMessage();
		System.out.println("OUT-" + msg);
		System.err.println("OUT-" + msg);
	}

	public static IDfSessionManager login(String m_docbase,String m_user,String m_password) throws DfException {
		if (m_docbase == null || m_user == null) {
			System.out
					.println("ERROR: docbase/user, one was null, cannot login.");
			return null;
		}

		// now login
		IDfClient dfClient = DfClient.getLocalClient();

		if (dfClient != null) {
			IDfLoginInfo li = new DfLoginInfo();
			li.setUser(m_user);
			li.setPassword(m_password);
			li.setDomain(null);

			IDfSessionManager sessionMgr = dfClient.newSessionManager();
			sessionMgr.setIdentity(m_docbase, li);
			return sessionMgr;
		}

		return null;
	}

	public static HashMap initParams(Map params) {
		
		HashMap returnParams = new HashMap();
		try {

			Set keys = params.keySet();
			System.out.println("nkeys: " + keys.size());
			Iterator iter = keys.iterator();
			while (iter.hasNext()) {
				String key = (String) iter.next();
				System.out.println("parsing key: " + key);
				if ((key == null) || (key.length() == 0)) {
					continue;
				}
				String[] value = (String[]) params.get(key);

				returnParams.put(key, (value.length > 0) ? value[0] : "");
				debug("param " + key + "=" + (String) returnParams.get(key) + "*");

			} // while

		} catch (NullPointerException exc) {
			System.out.println("NPE in initParams: " + exc.getMessage());
			exc.printStackTrace(System.err);
		}
		System.out.println("done with initParams()");
		
		return returnParams;
	}
	
	    
	    
} // class
